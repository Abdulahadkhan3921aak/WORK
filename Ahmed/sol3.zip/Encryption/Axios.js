const axios = require('axios');

const verifyAccess = async (transactionHash) => {
  const url = `https://nanexplorer.com/api/block/${transactionHash}`;
  const response = await axios.get(url);
  if (response.data) {
    console.log('Transaction Verified:', response.data);
    return true;
  }
  return false;
};
