const { OpenABE } = require('openabe');

const abe = new OpenABE();

exports.encryptWithPolicy = async (policy, data) => {
  await abe.setup();
  const encrypted = await abe.encrypt(policy, data);
  return encrypted;
};

exports.decryptWithAttributes = async (attributes, encryptedData) => {
  await abe.setup();
  const decrypted = await abe.decrypt(attributes, encryptedData);
  return decrypted;
};
