const mongoose = require('mongoose');

const HealthcareDataSchema = new mongoose.Schema({
  encryptedData: { type: String, required: true },
  iv: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('HealthcareData', HealthcareDataSchema);
