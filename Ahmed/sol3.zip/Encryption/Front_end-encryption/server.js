const connectDB = require('./db');
connectDB();
