const { encrypt, decrypt } = require('./encryption');
const HealthcareData = require('./models/HealthcareData'); // Your model

// Save encrypted data
const saveData = async (data) => {
  const { encryptedData, iv } = encrypt(JSON.stringify(data));
  const newEntry = new HealthcareData({ encryptedData, iv });
  await newEntry.save();
  console.log('Data saved successfully');
};

// Retrieve and decrypt data
const getData = async (id) => {
  const entry = await HealthcareData.findById(id);
  const decryptedData = decrypt(entry.encryptedData, entry.iv);
  console.log('Decrypted Data:', decryptedData);
};
