from enum import auto, IntEnum


class CardColor(IntEnum):
    """
    Enum class for the color of the card.
    Colors available: RED, BLUE, GREEN, YELLOW, CRAZY.
    """
    RED = 0
    BLUE = auto()
    GREEN = auto()
    YELLOW = auto()
    CRAZY = auto()


class CardLabel(IntEnum):
    """
    Enum class for the value of the card.
    Labels available: ZERO, ONE, TWO, ..., NINE, SKIP, REVERSE, DRAW_TWO, CRAZY, DRAW_FOUR.
    """
    ZERO = 0
    ONE = auto()
    TWO = auto()
    THREE = auto()
    FOUR = auto()
    FIVE = auto()
    SIX = auto()
    SEVEN = auto()
    EIGHT = auto()
    NINE = auto()
    SKIP = auto()
    REVERSE = auto()
    DRAW_TWO = auto()
    CRAZY = auto()
    DRAW_FOUR = auto()


class Card:
    """
    A class to represent a single card in a card game.

    Attributes:
        color (CardColor): The color of the card.
        label (CardLabel): The label or value of the card.
    """

    def __init__(self, color: CardColor, label: CardLabel) -> None:
        """
        Constructor for the Card class.

        Args:
            color (CardColor): The color of the card.
            label (CardLabel): The label of the card.

        Returns:
            None

        Complexity:
            Best Case Complexity: O(1) - Assigning the color and label.
            Worst Case Complexity: O(1) - Assigning the color and label.
        """
        self.color: CardColor = color  # O(1) - Assigning a value to color.
        self.label: CardLabel = label  # O(1) - Assigning a value to label.

    def __eq__(self, other: CardColor) -> bool:
        """
        Checks if the color of this card is equal to another card's color.

        Args:
            other (CardColor): The color to compare against.

        Returns:
            bool: True if the colors are equal, False otherwise.

        Complexity:
            O(1) - Comparing two colors.
        """
        return self.color == other  # O(1)

    def __gt__(self, other: CardColor) -> bool:
        """
        Checks if the color of this card is greater than another card's color.

        Args:
            other (CardColor): The color to compare against.

        Returns:
            bool: True if this card's color is greater, False otherwise.

        Complexity:
            O(1) - Comparing two colors.
        """
        return self.color > other  # O(1)

    def __lt__(self, other: CardColor) -> bool:
        """
        Checks if the color of this card is less than another card's color.

        Args:
            other (CardColor): The color to compare against.

        Returns:
            bool: True if this card's color is less, False otherwise.

        Complexity:
            O(1) - Comparing two colors.
        """
        return self.color < other  # O(1)

    def __ge__(self, other: CardColor) -> bool:
        """
        Checks if the color of this card is greater than or equal to another card's color.

        Args:
            other (CardColor): The color to compare against.

        Returns:
            bool: True if this card's color is greater than or equal, False otherwise.

        Complexity:
            O(1) - Comparing two colors.
        """
        return self.__gt__(other) or self.__eq__(other)  # O(1) - Uses `__gt__` and `__eq__` methods.

    def __le__(self, other: CardColor) -> bool:
        """
        Checks if the color of this card is less than or equal to another card's color.

        Args:
            other (CardColor): The color to compare against.

        Returns:
            bool: True if this card's color is less than or equal, False otherwise.

        Complexity:
            O(1) - Comparing two colors.
        """
        return self.__lt__(other) or self.__eq__(other)  # O(1) - Uses `__lt__` and `__eq__` methods.
