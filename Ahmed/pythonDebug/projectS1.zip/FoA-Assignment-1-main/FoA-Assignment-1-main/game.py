from data_structures.referential_array import ArrayR
from player import Player
from card import CardColor, CardLabel, Card
from random_gen import RandomGen
from constants import Constants
from data_structures.queue_adt import CircularQueue
from data_structures.stack_adt import ArrayStack


class Game:
    """
    Game class to play the game
    """

    def __init__(self) -> None:
        """
        Constructor for the Game class

        Args:
            None

        Returns:
            None
        """
        self.players: CircularQueue = CircularQueue(Constants.MAX_PLAYERS)
        self.draw_pile: ArrayStack = ArrayStack(Constants.DECK_SIZE)
        self.discard_pile: ArrayStack = ArrayStack(Constants.DECK_SIZE)
        self.current_player = None
        self.current_color = None
        self.current_label = None
        self.clockwise = True  # default direction of the game

    def generate_cards(self) -> ArrayR[Card]:
        """
        Method to generate the cards for the game

        Args:
            None

        Returns:
            ArrayR[Card]: The array of Card objects generated

        Complexity:
            Best Case Complexity: O(N)
            Worst Case Complexity: O(N)
        """
        list_of_cards: ArrayR[Card] = ArrayR(Constants.DECK_SIZE)
        idx: int = 0

        for color in CardColor:
            if color != CardColor.CRAZY:
                # Generate 4 sets of cards from 0 to 9 for each color
                for i in range(10):
                    list_of_cards[idx] = Card(color, CardLabel(i))
                    idx += 1
                    list_of_cards[idx] = Card(color, CardLabel(i))
                    idx += 1

                # Generate 2 of each special card for each color
                for i in range(2):
                    list_of_cards[idx] = Card(color, CardLabel.SKIP)
                    idx += 1
                    list_of_cards[idx] = Card(color, CardLabel.REVERSE)
                    idx += 1
                    list_of_cards[idx] = Card(color, CardLabel.DRAW_TWO)
                    idx += 1
            else:
                # Generate the crazy and crazy draw 4 cards
                for i in range(4):
                    list_of_cards[idx] = Card(CardColor.CRAZY, CardLabel.CRAZY)
                    idx += 1
                    list_of_cards[idx] = Card(CardColor.CRAZY, CardLabel.DRAW_FOUR)
                    idx += 1

        # Randomly shuffle the cards
        RandomGen.random_shuffle(list_of_cards)
        return list_of_cards

    def initialise_game(self, players: ArrayR[Player]) -> None:
        """
        Method to initialise the game

        Args:
            players (ArrayR[Player]): The array of players

        Returns:
            None
        """
        for player in players:
            self.players.append(player)

        cards = self.generate_cards()

        i = 0
        while i < len(cards):
            for _ in range(Constants.NUM_CARDS_AT_INIT):
                for _ in range(len(self.players)):
                    player = self.players.serve()
                    player.add_card(cards[i])
                    i += 1
                    self.players.append(player)
            break

        for index in range(i, len(cards)):
            self.draw_pile.push(cards[index])

        while len(self.draw_pile) > 0:
            stack = ArrayStack(Constants.DECK_SIZE)
            draw: Card = self.draw_pile.pop()

            if draw.label.name in ["SKIP", "REVERSE", "DRAW_TWO", "CRAZY", "DRAW_FOUR"]:
                stack.push(draw)
            else:
                self.current_color, self.current_label = draw.color, draw.label
                self.discard_pile.push(draw)
                while not stack.is_empty():
                    self.draw_pile.push(stack.pop())
                break

    def crazy_play(self, card: Card) -> None:
        if card.label == CardLabel.CRAZY:
            self.current_color = CardColor(RandomGen.randint(0, 3))


        if card.label == CardLabel.DRAW_FOUR:
            next_player = self.next_player()
            for _ in range(4):
                self.draw_card(next_player, False)
                self.current_color = CardColor(RandomGen.randint(0, 3))
            self.current_player = next_player  # Skip the next player's turn

    def play_reverse(self) -> None:
        """
        Method to play a reverse card

        Args:
            None

        Returns:
            None
        """
        self.clockwise = not self.clockwise

        stackp = ArrayStack(len(self.players))

        while not self.players.is_empty():
            stackp.push(self.players.serve())

        while not stackp.is_empty():
            self.players.append(stackp.pop())

    def play_skip(self) -> None:
        """
        Method to play a skip card

        Args:
            None

        Returns:
            None
        """
        self.current_player = self.next_player()

    def draw_card(self, player: Player, playing: bool) -> Card | None:
        if self.draw_pile.is_empty():
            self.reshuffle()

        # If the draw pile is still empty after reshuffling, end the game or take appropriate action
        if self.draw_pile.is_empty():
            print("The draw pile is empty, and the discard pile cannot be reshuffled. Game cannot continue.")
            return None

        card = self.draw_pile.pop()
        print(f"{player.name} draws a {card.color} {card.label} card")

        play = (
                card.color == self.current_color or
                card.label == self.current_label or
                card.color == CardColor.CRAZY
        )

        if playing and play:
            return card

        player.add_card(card)
        print(f"{player.name} cannot play the drawn card. Hand size: {len(player.hand)}")
        self.current_player = self.next_player()
        return None

    def reshuffle(self):
        if len(self.discard_pile) > 1 or self.discard_pile.is_empty():
            top_discard = self.discard_pile.pop()
            discard_size = len(self.discard_pile)
            temp_array = ArrayR(discard_size)

            for i in range(discard_size):
                temp_array[i] = self.discard_pile.pop()

            RandomGen.random_shuffle(temp_array)

            for card in temp_array:
                self.draw_pile.push(card)

            self.discard_pile.push(top_discard)
        else:
            print("The discard pile has less than 2 cards, cannot reshuffle.")

    def next_player(self) -> Player:
        """
        Method to get the next player

        Args:
            None

        Returns:
            Player: The next player
        """
        if self.current_player is None:
            return self.players.peek()

        current_index = None
        for index in range(len(self.players)):
            if self.players.array[(self.players.front + index) % len(self.players.array)] == self.current_player:
                current_index = index
                break

        if current_index is not None:
            next_index = (current_index + 1) % len(self.players)
            return self.players.array[(self.players.front + next_index) % len(self.players.array)]

    def play_game(self) -> Player:
        """
        Method to play the game

        Args:
            None

        Returns:
            Player: The winner of the game
        """
        self.current_player = self.players.peek()
        self.clockwise = True
        round_counter = 1  # To track the number of rounds

        while len(self.current_player.hand) != 0:
            print(f"\n--- Round {round_counter} ---")
            print(f"Current Player: {self.current_player.name}")

            top_card = self.discard_pile.peek()
            print(f"Top of Discard Pile: {top_card.color.name} {top_card.label.name}")
            playcard = None

            # Search for a playable card
            for index in range(len(self.current_player.hand)):
                card = self.current_player.hand[index]
                if card.color == top_card.color or card.label == top_card.label or card.color == CardColor.CRAZY or card.label == CardLabel.CRAZY or card.label == CardLabel.DRAW_FOUR:
                    playcard = self.current_player.play_card(index)
                    print(f"{self.current_player.name} plays {playcard.color.name} {playcard.label.name}")
                    break

            if playcard:
                self.discard_pile.push(playcard)
                self.current_color = playcard.color
                self.current_label = playcard.label

                if playcard.label == CardLabel.SKIP:
                    print(f"{self.current_player.name} plays SKIP. Next player's turn is skipped.")
                    self.play_skip()

                elif playcard.label == CardLabel.REVERSE:
                    print(f"{self.current_player.name} plays REVERSE. Game direction is reversed.")
                    self.play_reverse()

                elif playcard.label == CardLabel.DRAW_TWO:
                    next_player = self.next_player()
                    for _ in range(2):
                        self.draw_card(next_player, False)
                    self.current_player = next_player  # Skip the next player's turn

                elif playcard.label == CardLabel.DRAW_FOUR:
                    self.crazy_play(playcard)

                elif playcard.label == CardLabel.CRAZY:
                    self.crazy_play(playcard)

                next_player = self.next_player()
                self.current_player = next_player


            else:
                # No card to play, so draw one
                drawncard = self.draw_card(self.current_player, True)
                next_player = self.next_player()
                if drawncard:
                    self.discard_pile.push(drawncard)
                    self.current_color = drawncard.color
                    self.current_label = drawncard.label
                    self.current_player = next_player
                else:
                    self.current_player = next_player

            if len(self.current_player.hand) == 0:
                print(f"the {self.current_player} has 0 cards")
                # If it's a DRAW_TWO or DRAW_FOUR, enforce the effect on the next player before declaring the winner
                if playcard.label == CardLabel.DRAW_TWO:
                    next_player = self.next_player()
                    for _ in range(2):
                        self.draw_card(next_player, False)
                if playcard.label == CardLabel.DRAW_FOUR:
                    next_player = self.next_player()
                    for _ in range(4):
                        self.draw_card(next_player, False)
                        self.current_color = CardColor(RandomGen.randint(0, 3))

            # Move to the next player
            self.current_player = self.next_player()
            round_counter += 1
            return self.current_player



def test_case():
    players: ArrayR[Player] = ArrayR(4)
    players[0] = Player("Alice", 0)
    players[1] = Player("Bob", 1)
    players[2] = Player("Charlie", 2)
    players[3] = Player("David", 3)
    g: Game = Game()
    g.initialise_game(players)
    winner: Player = g.play_game()
    print(f"Winner is {winner.name}")


if __name__ == '__main__':
    test_case()
