package com.d288.idris.services;

import com.d288.idris.entities.Customer;
import com.d288.idris.entities.Cart;
import com.d288.idris.services.Purchase;
import com.d288.idris.services.PurchaseResponse;
import com.d288.idris.dao.CustomerRepository;
import com.d288.idris.dao.CartRepository;
import com.d288.idris.dao.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Service
public class CheckoutServiceImpl implements CheckoutService {

    private final CustomerRepository customerRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;

    @Autowired
    public CheckoutServiceImpl(CustomerRepository customerRepository, CartRepository cartRepository, CartItemRepository cartItemRepository) {
        this.customerRepository = customerRepository;
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
    }

    @Override
    @Transactional
    public PurchaseResponse placeOrder(Purchase purchase) {
        // Retrieve the customer from the purchase service
        Customer customer = purchase.getCustomer();

        // Check if this is an existing customer by ID
        Long customerId = customer.getId();
        Optional<Customer> existingCustomerOpt = customerRepository.findById(customerId);
        if (existingCustomerOpt.isPresent()) {
            customer = existingCustomerOpt.get();
        }

        // Retrieve the cart from the DTO
        Cart cart = purchase.getCart();

        // Generate a unique order tracking number
        String orderTrackingNumber = generateOrderTrackingNumber();
        cart.setOrderTrackingNumber(orderTrackingNumber);

        // Add the cart to the customer's carts
        Set<Cart> carts = customer.getCarts();
        carts.add(cart);
        customer.setCarts(carts);

        // Save the customer and cascade the changes (cart and cart items will be saved)
        customerRepository.save(customer);

        // Return a response with the order tracking number
        return new PurchaseResponse(orderTrackingNumber);
    }

    private String generateOrderTrackingNumber() {
        // Generate a random UUID number (UUID version-4)
        return UUID.randomUUID().toString();
    }
}
