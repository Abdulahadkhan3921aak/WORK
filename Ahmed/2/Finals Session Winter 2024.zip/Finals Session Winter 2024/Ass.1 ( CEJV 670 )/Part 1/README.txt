This is a two part assigment. This section must be first completed fulfilling the requirements indicated in the instructions pdf. 

In this folder you will also find a .zip with a (completed) version fulfilling the requirements in the instructions- Although there is likely to be some errors and missing items it is a bassis to start and should not require you to write this code from scratch. 

once this is completed you may continue to part two where you will find a new set of instructions in which you will need to fulfill and build upon using this code. 

The final goal of this assigment will be completed and finished in Part 2 