This PDF document in this folder are the instructions to complete this Project Assigment. 

You must use the completed code from Part 1 and build onto it while fulfilling the requirements indicated in this PDF document in Part 2 

The Assignment will be completed once you have finished this and can be submitted as completed as final in this part 