In this section you must complete the requirements in the document attached and that is all. 

All necessary instructions to do should be adequately indicated in the PDF file. 

Thank you for all your help thank you 