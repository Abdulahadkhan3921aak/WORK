package grid01;

public class Ship {

	private int length;
	private String type;
	private int points;
}
