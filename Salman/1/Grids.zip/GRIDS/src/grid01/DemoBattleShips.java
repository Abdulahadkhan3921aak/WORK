package grid01;

public class DemoBattleShips {
	public static void main(String[] args) {
		BattleShips bs = new BattleShips();
		
		bs.play();

	}

}
