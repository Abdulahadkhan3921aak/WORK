package grid02;

public class Grid {
	private final int GRID_WIDTH = 10;
	private final int GRID_HEIGHT = 10;
	
	//private int [] [] theGrid = new int [GRID_WIDTH] [GRID_HEIGHT];
	
	private Square [] [] anotherGrid = new Square [GRID_WIDTH] [GRID_HEIGHT];

}
