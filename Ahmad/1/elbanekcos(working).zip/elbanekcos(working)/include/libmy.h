/*
** EPITECH PROJECT, 2017
** libmy.h
** File description:
** Contain all the prototypes of function in libmy
*/

#include <stdarg.h>
#ifndef LIBMY_H
#define LIBMY_H
	void my_putchar(char c);
	int my_putstr(char const *str);
#endif
