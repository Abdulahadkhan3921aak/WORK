# Deadlock and Optimizations

Explain your optimizations if applicable