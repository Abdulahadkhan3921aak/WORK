The code is built For Linux operating system using make 

Run the code with commands like:

./sokoban <-s> "map" <play_solution>

the -s agruments runs the AI to solve the map

map is the path to the available map

the play_solution argument will play the solution found by the AI so us is with the -s argument

deafult is : ./sokoban -s testmap.txt play_solution
can also use : ./sokoban testmap.txt to play it your self

more maps available it the test_maps folder

maps is the maps_suits folder can also be used but would require to be copy pasted in a new text file
as these file contains maps that are bunched up for benchmark testing